public interface Constantes {

    public static final String A = "Parabéns, você atingiu todos os indicadores de avaliação com excelência";
    public static final String B = "Parabéns, você obteve aproveitamento satisfatório nos indicadores de avaliação";
    public static final String C = "Você não atingiu o mínimo esperado para aprovação";
}