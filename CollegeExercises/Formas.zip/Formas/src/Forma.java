abstract class Forma {
    String cor;
    Boolean preenchido ;
    
    public Forma() {}

    public abstract double getArea();

}
