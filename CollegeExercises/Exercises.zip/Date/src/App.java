import Date.Date;

public class App {
    public static void main(String[] args) throws Exception {
        
        Date date1 = new Date(17, 11, 89);

        date1.showDate();
    }
}
